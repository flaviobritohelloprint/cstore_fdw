/* cstore_fdw/cstore_fdw--1.3--1.4.sql */

-- No new functions or definitions were added in 1.4
